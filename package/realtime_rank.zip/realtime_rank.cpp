#include "realtime_rank.h"

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

struct PNode{
	PNode(double id):
		pid(id)
		//,order(0)
		,pre(NULL)
		,next(NULL)
	{}
	const double pid;
	//int order;
	PNode * pre;
	PNode * next;
};

class SameScoreList {
public:
	SameScoreList(int score):
		_count(0)
		, _head(NULL)
		, _tail(NULL)
		, _score(score)
	{}
	~SameScoreList(){
		for (map<double, PNode*>::iterator it= _pids.begin(); it != _pids.end(); ++it)
			delete it->second;
	}
	map<double, PNode*> _pids;
	int _count;
	PNode* _head;
	PNode* _tail;
	const int _score;
public:
	inline int count() {
		return this->_count;
	}

	int push(PNode * e) {
		if (this->_pids.find(e->pid) != this->_pids.end())  {
			assert(0);
			return -1;
		}
		this->_count = this->_count + 1;
		//e->order = this->_count;
		this->_pids[e->pid] = e;
		if (!this->_head) {
			assert(!this->_tail);
			this->_head = e;
			this->_tail = e;
		} else {
			this->_tail->next = e;
			e->pre = this->_tail;
			this->_tail = e;
		}
		return 0;
	}

	PNode* erase(double pid) {
		map<double, PNode*>::iterator it = _pids.find(pid);
		if (it == _pids.end()) {
			return NULL;
		}
		
		PNode * e = it->second;
		_pids.erase(it);
		if (e == this->_head) {
			this->_head = e->next;
			if (!this->_head)
				this->_tail = NULL;
			else
				this->_head->pre = NULL;
		}
		else if (e == this->_tail) {
			this->_tail = e->pre;
			assert(this->_tail);
			this->_tail->next = NULL;
		} else {
			e->pre->next = e->next;
			e->next->pre = e->pre;
		}
		this->_count = this->_count - 1;
		/*PNode * c = e;
		int order = e->order;
		while (c && c->next) {//reset order
			c = c->next;
			c->order = order;
			order = order + 1;
		}
		*/
		e->pre = NULL;
		e->next = NULL;
		return e;
	}

	int scanTopn (int n, int base, RankScanCalc calc, void * ud) {
		if (n <=0 )
			return 0;

		PNode * node = this->_head;
		int cn = 0;
		while (node) {
			int r = base + cn + 1;
			calc(node->pid, _score, r, ud);
			node = node->next;
			if (++cn >= n)
				break;
		}
		return cn;
	}
};

//-------------------------------

RealtimeRank::RealtimeRank() {

}

RealtimeRank::~RealtimeRank() {
	for (map<int, SameScoreList*>::iterator it= _scores.begin(); it != _scores.end(); ++it)
		delete it->second;
}

void 
RealtimeRank::update(double pid, int score) {
	PNode* e = NULL;
	map <double, int>::iterator itps = _pscore.find(pid);
	if (itps != _pscore.end()) {
		if (itps->second == score)
			return;
		
		map <int, SameScoreList*>::iterator itold = _scores.find(itps->second);
		if (itold != _scores.end()) {
			e = itold->second->erase(pid);
			assert(e);
			if (itold->second->count() <= 0) {
				delete itold->second;
				_scores.erase(itold);
			}
		}
	}
	
	SameScoreList * plist = NULL;
	map <int, SameScoreList*>::iterator itscore = _scores.find(score);
	if (itscore == _scores.end()) {
		plist = new SameScoreList(score);
		_scores[score] = plist;
	} else
		plist = itscore->second;
	
	if (!e)
		e = new PNode(pid);
	
	_pscore[pid] = score;
	assert(e);
	assert(plist);
	int ret = plist->push(e);
	assert(ret == 0);
}

void 
RealtimeRank::erase(double pid) {
	map <double, int>::iterator itps = _pscore.find(pid);
	if (itps != _pscore.end()) {
		map <int, SameScoreList*>::iterator itold = _scores.find(itps->second);
		if (itold != _scores.end()) {
			PNode * e = itold->second->erase(pid);
			assert(e);
			delete e;
			if (itold->second->count() <= 0) {
				delete itold->second;
				_scores.erase(itold);
			}
		}
	}
}

void 
RealtimeRank::rankTopn(int n, RankScanCalc calc, void * ud) {
	if (n <= 0)
		return;

	int need = n;
	int scaned = 0;
	for (map <int, SameScoreList*>::reverse_iterator iter = _scores.rbegin(); iter != _scores.rend(); ++iter) {
		int count = iter->second->count();
		assert(count >= 0);
		int scan = count;
		if (scaned + scan >= need) {
			scan = need - scaned;
			int n = iter->second->scanTopn(scan, scaned, calc, ud);
			assert(n == scan);
			scaned += scan;
			break;
		}
		else {
			int n = iter->second->scanTopn(scan, scaned, calc, ud);
			assert(n == scan);
			scaned += scan;
		}

	}
}
/*
#include <sys/time.h>
#include <time.h>
#include <stdint.h>
int64_t __getms() {
	struct timeval tv;
	gettimeofday(&tv, NULL);
	return (((int64_t)tv.tv_sec) * 1000) + ((tv.tv_usec+500) / 1000);
}

map<int, int>mmm;
void _scanCB(double pid, int v, int rank, void * ud) {
	assert(mmm.find(pid) == mmm.end());
	mmm[pid]=1;
	printf("p:%5d, v:%5d,  r:%5d\n", (int)pid, v, rank);
}

int main() {
	RealtimeRank mgr;
	int64_t stm = __getms();
	for (int i = 0; i < 10; i++) {
		mgr.update(i, random()%1000);
	}
	printf("cost 1 :%d\n", __getms() - stm);
	stm = __getms();
	for (int i = 0; i < 10; i++) {
		mgr.update(i, random()%1000);
	}
	printf("cost 2 :%d\n", __getms() - stm);

	mgr.update(5, 20001);
	mgr.update(6, 10001);
	mgr.update(7, 10001);
	mgr.update(9, 10001);
	mgr.update(8, 10001);
	mgr.erase(7);
	mgr.rankTopn(10, _scanCB, NULL);
	return 1;
}*/