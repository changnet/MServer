#ifndef REALTIME_RANK_H
#define REALTIME_RANK_H
#include <map>
using namespace std;

typedef void(*RankScanCalc)(double pid, int score, int rank, void * ud);
class SameScoreList;

class RealtimeRank {
private:
	map <double, int> _pscore;
	map <int, SameScoreList*> _scores;
	RealtimeRank(RealtimeRank &) {}
public:
	RealtimeRank();
	~RealtimeRank();
public:
	void update(double pid, int score);
	void erase(double pid);
	void rankTopn(int n, RankScanCalc calc, void * ud);
};

#endif