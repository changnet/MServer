#ifndef LUA_REALTIME_RANK_H
#define LUA_REALTIME_RANK_H
#include "realtime_rank.h"
#include <lua.hpp>

namespace lua {
class LuaRealTimeRank {
public:
	LuaRealTimeRank(lua_State * L){}
	~LuaRealTimeRank(){}

	static const char className[];
	static void registerToLua(lua_State * L);

	int update(lua_State * L);
	int erase(lua_State * L);
	int rankTopn(lua_State * L);
private:
	RealtimeRank _rank;
};
}
#endif