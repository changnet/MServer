#include "lua_realtime_rank.h"
#include "../../util/lua_class.h"
#include "../../util/define.h"
namespace lua {
const char LuaRealTimeRank::className[] = "CRealTimeRank";

int 
LuaRealTimeRank::update(lua_State * L) {
	const double pid = luaL_checknumber(L, 2);
	const int v = luaL_checkinteger(L, 3);
	_rank.update(pid, v);
	return 0;
}

int 
LuaRealTimeRank::erase(lua_State * L) {
	const double pid = luaL_checknumber(L, 2);
	_rank.erase(pid);
	return 0;
}

static void _scanCB(double pid, int v, int rank, void * ud) {
	int st = lua_gettop((lua_State*)ud);
	lua_pushcfunction((lua_State*)ud, lua_error_cb);
	lua_pushvalue((lua_State*)ud, 3);
	lua_pushnumber((lua_State*)ud, pid);
	lua_pushinteger((lua_State*)ud, v);
	lua_pushinteger((lua_State*)ud, rank);
	lua_pcall((lua_State*)ud, 3, 0, -5);
	lua_settop((lua_State*)ud, st);
}

int 
LuaRealTimeRank::rankTopn(lua_State * L) {
	const int n = luaL_checkinteger(L, 2);
	_rank.rankTopn(n, _scanCB, (void*)L);
	return 0;
}

void 
LuaRealTimeRank::registerToLua(lua_State * L) {
	lua::LuaClass<LuaRealTimeRank> lc(L);
	lc.def<&LuaRealTimeRank::update>("update");
	lc.def<&LuaRealTimeRank::erase>("erase");
	lc.def<&LuaRealTimeRank::rankTopn>("rankTopn");
}

}