Syntax.layouts.yelp = function(options, code, container) {
  code.addClass('contents');
  return code;
};
