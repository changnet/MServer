#include <stdio.h>

static const char * const value = KEY;

int main() {
    printf("%s\n", value);
    return 0;
}
