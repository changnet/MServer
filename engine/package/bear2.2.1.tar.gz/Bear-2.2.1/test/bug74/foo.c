int foo() {
    return 0;
}
